#include<stdio.h>

int main()
{
    int id;
    scanf("my id: %d", id);

    int div = id / 2;
    printf("%d ", div);

}