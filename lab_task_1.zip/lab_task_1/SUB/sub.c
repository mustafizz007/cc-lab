#include<stdio.h>

int main()
{
    int id;
    scanf("my id: %d", id);

    int dif = id - 2;
    printf("%d ", dif);

}